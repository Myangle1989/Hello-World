@javax.xml.bind.annotation.XmlSchema(namespace = "http://webservice.notify.sys.kmss.landray.com/")
package com.landray.kmss.sys.notify.webservice;
